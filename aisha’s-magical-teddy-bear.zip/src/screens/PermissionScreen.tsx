import { motion } from 'motion/react';
import { useSecretsStore } from '../store/useSecretsStore';
import { Camera, ArrowLeft } from 'lucide-react';
import { TeddyBear } from '../components/TeddyBear';

export const PermissionScreen = () => {
  const setScreen = useSecretsStore(state => state.setScreen);

  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      exit={{ opacity: 0 }}
      className="flex flex-col items-center justify-center min-h-[100dvh] p-6 relative"
    >
      <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-amber-100 via-rose-50 to-white -z-10" />
      
      <TeddyBear state="shy" />
      
      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="mt-8 bg-white/80 backdrop-blur-md p-6 rounded-3xl shadow-xl shadow-slate-200/50 max-w-sm w-full text-center border border-white"
      >
        <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4 text-amber-600">
          <Camera size={24} />
        </div>
        
        <h2 className="text-xl font-bold text-slate-800 mb-2">عشان تشوفي المفاجأة</h2>
        <p className="text-slate-600 mb-6 text-sm leading-relaxed">
          الدبدوب محتاج يشوفك عشان يتفاعل معاكي بحركات إيدك. الصور مابتتسجلش ولا بتتبعت لأي مكان، كل حاجة بتحصل على موبايلك بس.
        </p>
        
        <button 
          onClick={() => setScreen('experience')}
          className="w-full bg-slate-800 hover:bg-slate-900 text-white px-6 py-4 rounded-xl font-medium transition-all shadow-md mb-3"
        >
          موافقة، افتح الكاميرا
        </button>
        
        <button 
          onClick={() => setScreen('welcome')}
          className="w-full flex items-center justify-center gap-2 text-slate-500 hover:text-slate-800 px-6 py-3 transition-colors text-sm font-medium"
        >
          <ArrowLeft size={16} />
          <span>رجوع</span>
        </button>
      </motion.div>
    </motion.div>
  );
};
