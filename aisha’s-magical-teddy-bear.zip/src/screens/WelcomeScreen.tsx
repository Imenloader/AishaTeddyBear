import { motion } from 'motion/react';
import { useSecretsStore } from '../store/useSecretsStore';
import { TeddyBear } from '../components/TeddyBear';
import { Play } from 'lucide-react';

export const WelcomeScreen = () => {
  const setScreen = useSecretsStore(state => state.setScreen);

  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      exit={{ opacity: 0 }}
      className="flex flex-col items-center justify-center min-h-[100dvh] p-6 relative"
    >
      <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-rose-100 via-rose-50 to-white -z-10" />
      
      <TeddyBear state="idle" />
      
      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="mt-8 text-center"
      >
        <h1 className="text-3xl font-bold text-slate-800 mb-2">أهلاً يا عائشة 🌷</h1>
        <p className="text-slate-600 mb-8 max-w-xs mx-auto leading-relaxed">
          عندي لك مفاجأة صغيرة، حاجة معمولة مخصوص علشانك..
        </p>
        
        <button 
          onClick={() => setScreen('permission')}
          className="flex items-center gap-2 mx-auto bg-rose-500 hover:bg-rose-600 text-white px-8 py-4 rounded-full font-medium transition-all shadow-lg shadow-rose-200 hover:shadow-rose-300 hover:-translate-y-0.5 active:translate-y-0"
        >
          <span>يلا نبدأ</span>
          <Play size={18} fill="currentColor" />
        </button>
      </motion.div>
    </motion.div>
  );
};
