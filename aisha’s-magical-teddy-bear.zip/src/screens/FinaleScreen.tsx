import { useEffect } from 'react';
import { motion } from 'motion/react';
import { useSecretsStore } from '../store/useSecretsStore';
import { FINAL_SECRET } from '../data/secrets';
import { TeddyBear } from '../components/TeddyBear';
import { RotateCcw } from 'lucide-react';
import confetti from 'canvas-confetti';

export const FinaleScreen = () => {
  const { currentBearState, setBearState, reset } = useSecretsStore();
  
  useEffect(() => {
    setBearState('surprise');
    
    const duration = 2500;
    const end = Date.now() + duration;

    const frame = () => {
      confetti({
        particleCount: 5,
        angle: 60,
        spread: 55,
        origin: { x: 0 },
        colors: ['#f43f5e', '#fbbf24', '#38bdf8']
      });
      confetti({
        particleCount: 5,
        angle: 120,
        spread: 55,
        origin: { x: 1 },
        colors: ['#f43f5e', '#fbbf24', '#38bdf8']
      });

      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    };
    frame();

    const sleepTimer = setTimeout(() => {
      setBearState('sleep');
      // Play audio when entering sleep state
      const audio = document.getElementById('finale-audio') as HTMLAudioElement;
      if (audio) {
        audio.play().catch(e => console.warn("Audio autoplay prevented", e));
      }
    }, 4000);

    return () => clearTimeout(sleepTimer);
  }, [setBearState]);

  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      className={`flex flex-col items-center justify-center min-h-[100dvh] p-6 relative transition-colors duration-[3000ms] ${
        currentBearState === 'sleep' ? 'bg-indigo-950' : 'bg-rose-100'
      }`}
    >
      <audio id="finale-audio" src="/assets/finale-voice.mp3" preload="auto" />
      
      <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-transparent to-black/30 -z-10" />
      
      <div className="z-10">
        <TeddyBear state={currentBearState} />
      </div>
      
      <div className="h-64 mt-8 flex flex-col items-center justify-center w-full z-10">
        {currentBearState === 'sleep' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 2 }}
            className="text-center w-full max-w-sm flex flex-col items-center"
          >
            <h2 className="text-3xl font-bold text-indigo-100 mb-6">عائشة</h2>
            <p className="text-indigo-200/90 leading-loose mx-auto bg-indigo-900/40 p-6 rounded-3xl backdrop-blur-md border border-indigo-700/50 shadow-2xl mb-8">
              {FINAL_SECRET.message}
            </p>
            
            <button 
              onClick={reset}
              className="flex items-center gap-2 text-indigo-300/60 hover:text-indigo-200 text-sm transition-colors"
            >
              <RotateCcw size={14} />
              <span>إعادة التجربة</span>
            </button>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
};
