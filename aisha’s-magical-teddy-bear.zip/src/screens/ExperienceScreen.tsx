import { useEffect, useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useSecretsStore } from '../store/useSecretsStore';
import { SECRETS } from '../data/secrets';
import { CameraFeed } from '../components/CameraFeed';
import { TeddyBear } from '../components/TeddyBear';
import { GestureType } from '../types';

export const ExperienceScreen = () => {
  const { 
    currentBearState, setBearState, 
    currentMessage, setCurrentMessage,
    discoveredSecrets, addDiscoveredSecret,
    setScreen, isFinaleTriggered, triggerFinale
  } = useSecretsStore();
  
  const [showIntro, setShowIntro] = useState(true);
  const timeoutRef = useRef<number | null>(null);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowIntro(false);
    }, 4000);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (discoveredSecrets.length >= 6 && !isFinaleTriggered) {
      triggerFinale();
    }
  }, [discoveredSecrets, isFinaleTriggered, triggerFinale]);

  useEffect(() => {
    if (isFinaleTriggered) {
      const timer = setTimeout(() => {
        setScreen('finale');
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [isFinaleTriggered, setScreen]);

  const handleGesture = (gesture: GestureType) => {
    if (isFinaleTriggered) return;

    const secret = SECRETS.find(s => s.gesture === gesture);
    if (secret) {
      addDiscoveredSecret(secret.id);
      setBearState(secret.state);
      
      let randomMsg;
      if (secret.variants.length > 1) {
        do {
          randomMsg = secret.variants[Math.floor(Math.random() * secret.variants.length)];
        } while (randomMsg === currentMessage);
      } else {
        randomMsg = secret.variants[0];
      }
      
      setCurrentMessage(randomMsg);
      setShowIntro(false);
      
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      
      let duration = 3000;
      if (secret.state === 'love') duration = 4000;
      if (secret.state === 'reading') duration = 5000;
      
      timeoutRef.current = setTimeout(() => {
        setBearState('idle');
        setCurrentMessage(null);
      }, duration) as unknown as number;
    }
  };
  
  useEffect(() => {
    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, []);

  const totalSecrets = 7;

  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      exit={{ opacity: 0 }}
      className="flex flex-col items-center justify-between min-h-[100dvh] p-4 relative overflow-hidden"
    >
      <div className={`absolute top-0 left-0 w-full h-full -z-10 transition-colors duration-1000 ${
        currentBearState === 'love' ? 'bg-pink-50' :
        currentBearState === 'shy' ? 'bg-rose-50' :
        currentBearState === 'reading' ? 'bg-amber-50' :
        'bg-slate-50'
      }`} />
      
      <div className="w-full flex justify-center pt-2">
        <div className="flex gap-2">
          {Array.from({ length: totalSecrets }).map((_, i) => {
            const isDiscovered = i < discoveredSecrets.length || (i === 6 && isFinaleTriggered);
            return (
              <motion.div 
                key={i}
                initial={false}
                animate={{ 
                  scale: isDiscovered ? 1.2 : 1,
                  backgroundColor: isDiscovered ? '#f43f5e' : '#cbd5e1'
                }}
                className="w-2.5 h-2.5 rounded-full"
              />
            );
          })}
        </div>
      </div>

      <div className="h-28 w-full max-w-sm flex items-center justify-center mt-2 z-20">
        <AnimatePresence mode="wait">
          {showIntro ? (
            <motion.div
              key="intro"
              initial={{ opacity: 0, y: 10, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.9 }}
              className="bg-white/90 backdrop-blur-sm px-6 py-4 rounded-2xl shadow-sm border border-slate-100 text-center text-slate-700"
            >
              عائشة... عندي 7 حاجات مخبيها لك. بس مش هقولهم إلا لما تكتشفيهم بنفسك 🧸
              <div className="text-xs text-slate-400 mt-2">حركي إيدك قدام الكاميرا!</div>
            </motion.div>
          ) : currentMessage ? (
            <motion.div
              key="msg"
              initial={{ opacity: 0, y: 10, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className={`px-6 py-4 rounded-2xl shadow-md text-center w-[90%] font-medium text-lg leading-relaxed ${
                currentBearState === 'love' ? 'bg-pink-100 text-pink-800 border-pink-200' :
                currentBearState === 'reading' ? 'bg-amber-100 text-amber-800 border-amber-200' :
                'bg-white text-slate-800 border-slate-100'
              } border`}
            >
              {currentMessage}
            </motion.div>
          ) : null}
        </AnimatePresence>
      </div>

      <div className="flex-1 flex items-center justify-center my-2 relative w-full z-10">
         <TeddyBear state={currentBearState} />
         
         {currentBearState === 'idle' && discoveredSecrets.length === 0 && !showIntro && (
           <motion.div 
             initial={{ opacity: 0 }}
             animate={{ opacity: 1 }}
             transition={{ delay: 2 }}
             className="absolute bottom-0 text-slate-400 text-sm flex items-center gap-2"
           >
             <motion.span animate={{ x: [-5, 5, -5] }} transition={{ repeat: Infinity, duration: 1.5 }}>
               👋
             </motion.span>
             جربي تشاوري بإيدك (كف مفتوح)
           </motion.div>
         )}
      </div>

      <div className="mb-4 z-20">
        <CameraFeed onGesture={handleGesture} isActive={!isFinaleTriggered} />
      </div>
      
    </motion.div>
  );
};
