import { FinalSecret, SecretMessage } from "../types";

export const SECRETS: SecretMessage[] = [
  {
    id: "welcome",
    gesture: "Open_Palm",
    state: "happy",
    variants: [
      "أهلاً يا عائشة! كنت مستنيكي 🌷",
      "يا هلا يا هلا! نورتي يا عائشة ✨",
      "أخيراً جيتي! وحشتيني 🧸"
    ]
  },
  {
    id: "encouragement",
    gesture: "Thumb_Up",
    state: "happy",
    variants: [
      "أنتِ قوية وتقدري تعملي أي حاجة! 💪",
      "دايماً خليكي فخورة بنفسك يا عائشة 🌟",
      "ابتسامتك بتنور الدنيا كلها! 😊"
    ]
  },
  {
    id: "message_of_the_day",
    gesture: "Pointing_Up",
    state: "reading",
    variants: [
      "[رسالة اليوم هنا: افتكري دايماً إنك مميزة]",
      "[رسالة اليوم هنا: متنسيش تشربي مية وتاخدي بالك من نفسك]",
      "[رسالة اليوم هنا: النهارده يوم جديد عشان تحققي أحلامك]"
    ]
  },
  {
    id: "poem",
    gesture: "Victory",
    state: "reading",
    variants: [
      "[قصيدة قصيرة هنا: عائشة يا نور العين، ضحكتك تسوى كتير...]",
      "[قصيدة قصيرة هنا: في كل يوم جديد، أمنياتي ليكي تزيد...]"
    ]
  },
  {
    id: "love",
    gesture: "ILoveYou",
    state: "love",
    variants: [
      "بحبك جداً يا عائشة! ❤️",
      "أنتِ غالية عندي أوي! 💖",
      "مكانتك في قلبي كبيرة! 💝"
    ]
  },
  {
    id: "shy",
    gesture: "Closed_Fist",
    state: "shy",
    variants: [
      "يا مكسوفة! 🙈",
      "بتخبيني ليه؟ أنا بحب أشوفك! 🫣",
      "طيب أنا كمان هتكسف! 🙊"
    ]
  }
];

export const FINAL_SECRET: FinalSecret = {
  state: ["surprise", "sleep"],
  message: "[الرسالة الختامية: دايماً هكون هنا جنبك.. خلي بالك من نفسك، وتصبحي على خير يا أحلى عائشة 🌙]"
};
