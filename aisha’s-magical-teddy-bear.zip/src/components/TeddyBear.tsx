import { motion, Variants } from 'motion/react';
import { BearState } from '../types';

export const TeddyBear = ({ state }: { state: BearState }) => {
  const bodyVariants: Variants = {
    idle: { 
      scaleX: [1, 1.03],
      scaleY: [1, 1.03], 
      transition: { 
        type: "spring",
        stiffness: 40,
        damping: 10,
        repeat: Infinity, 
        repeatType: "mirror" 
      } 
    },
    happy: { y: [0, -15, 0], transition: { repeat: Infinity, duration: 0.6, ease: "easeOut" } },
    shy: { scaleY: 0.95, y: 5 },
    love: { scaleY: [1, 1.03, 1], transition: { repeat: Infinity, duration: 1.5 } },
    reading: { scaleY: 1, y: 5 },
    surprise: { scaleY: 1.1, y: -10, transition: { type: "spring", stiffness: 300 } },
    sleep: { scaleY: [1, 1.03, 1], transition: { repeat: Infinity, duration: 3, ease: "easeInOut" } }
  };

  const headVariants: Variants = {
    idle: { rotate: [-2, 2, -2], transition: { repeat: Infinity, duration: 4, ease: "easeInOut" } },
    happy: { rotate: [-5, 5, -5], transition: { repeat: Infinity, duration: 0.6 } },
    shy: { rotate: 8, y: 8 },
    love: { rotate: [-3, 3, -3], transition: { repeat: Infinity, duration: 2 } },
    reading: { rotate: -15, y: 5 }, 
    surprise: { y: -10 },
    sleep: { rotate: 8, y: 5 }
  };

  // Move arms up to cover the face in shy state
  const armLeftVariants: Variants = {
    idle: { rotate: 0, y: 0 },
    happy: { rotate: -130, y: -20, transition: { repeat: Infinity, duration: 0.6, repeatType: "reverse" } },
    shy: { rotate: -140, x: 25, y: -15 }, 
    love: { rotate: -45, x: 10, y: -5 }, 
    reading: { rotate: -50, x: 10, y: -10 }, 
    surprise: { rotate: -120, y: -20 },
    sleep: { rotate: -20, y: 10 }
  };

  const armRightVariants: Variants = {
    idle: { rotate: 0, y: 0 },
    happy: { rotate: 130, y: -20, transition: { repeat: Infinity, duration: 0.6, repeatType: "reverse" } },
    shy: { rotate: 140, x: -25, y: -15 }, 
    love: { rotate: 45, x: -10, y: -5 }, 
    reading: { rotate: 50, x: -10, y: -10 }, 
    surprise: { rotate: 120, y: -20 },
    sleep: { rotate: 20, y: 10 }
  };
  
  const eyeVariants: Variants = {
    idle: { scaleY: [1, 1, 0.1, 1, 1], transition: { repeat: Infinity, duration: 3.5, times: [0, 0.45, 0.5, 0.55, 1] } }, 
    happy: { scaleY: [1, 0.2, 1], transition: { repeat: Infinity, duration: 2 } },
    shy: { scaleY: 0.4 },
    love: { scaleY: 1 },
    reading: { scaleY: 0.8 },
    surprise: { scaleY: 1.5, scaleX: 1.2 },
    sleep: { scaleY: 0.1 } 
  };

  return (
    <div className="relative w-64 h-64 flex items-center justify-center">
      {/* Heart Particle Emitter for 'love' state */}
      {state === 'love' && (
        <div className="absolute inset-0 pointer-events-none z-30">
          {[...Array(5)].map((_, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 20, x: 0, scale: 0.5 }}
              animate={{ 
                opacity: [0, 1, 0], 
                y: -100 - (Math.random() * 50), 
                x: (Math.random() - 0.5) * 100,
                scale: [0.5, 1.2, 1]
              }}
              transition={{ 
                repeat: Infinity, 
                duration: 2 + Math.random(), 
                delay: Math.random() * 2,
                ease: "easeOut" 
              }}
              className="absolute text-pink-500 top-1/4 left-1/2 -ml-3 drop-shadow-md"
            >
              <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor" stroke="none">
                <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
              </svg>
            </motion.div>
          ))}
        </div>
      )}

      {/* SVG Scroll for 'reading' state */}
      {state === 'reading' && (
        <motion.div 
          initial={{ opacity: 0, y: 20, rotate: 10, scale: 0.8 }}
          animate={{ opacity: 1, y: 0, rotate: -5, scale: 1 }}
          transition={{ type: "spring", stiffness: 200, damping: 15 }}
          className="absolute z-20 top-32 drop-shadow-lg"
        >
          <svg width="60" height="70" viewBox="0 0 60 70" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="5" y="10" width="50" height="50" fill="#FEF3C7" stroke="#D97706" strokeWidth="2" rx="2" />
            <path d="M5 15C5 12.2386 7.23858 10 10 10H50V15H5Z" fill="#FDE68A" stroke="#D97706" strokeWidth="2" />
            <path d="M5 60C5 57.2386 7.23858 55 10 55H50V60H5Z" fill="#FDE68A" stroke="#D97706" strokeWidth="2" />
            <line x1="15" y1="25" x2="45" y2="25" stroke="#D97706" strokeWidth="2" strokeLinecap="round" />
            <line x1="15" y1="35" x2="40" y2="35" stroke="#D97706" strokeWidth="2" strokeLinecap="round" />
            <line x1="15" y1="45" x2="30" y2="45" stroke="#D97706" strokeWidth="2" strokeLinecap="round" />
          </svg>
        </motion.div>
      )}

      {state === 'surprise' && (
        <motion.div 
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: 1, scale: 1, rotate: [0, 10, -10, 0] }}
          transition={{ type: "spring", delay: 0.2 }}
          className="absolute z-30 text-xs bottom-12 right-12 drop-shadow-sm"
          title="Nano Banana"
        >
          🍌
        </motion.div>
      )}

      <motion.svg viewBox="0 0 200 200" className="w-full h-full overflow-visible relative z-10">
        <motion.g animate={state} initial="idle">
          {/* Body */}
          <motion.g variants={bodyVariants} style={{ originX: '100px', originY: '150px' }}>
            <path d="M 60 135 C 60 180, 140 180, 140 135 C 140 100, 60 100, 60 135" fill="#A87B51" stroke="#8A613C" strokeWidth="2" />
            <path d="M 75 140 C 75 170, 125 170, 125 140 C 125 115, 75 115, 75 140" fill="#E5C3A6" />
          </motion.g>

          {/* Head Group */}
          <motion.g variants={headVariants} style={{ originX: '100px', originY: '100px' }}>
            {/* Left Ear */}
            <circle cx="65" cy="65" r="15" fill="#A87B51" stroke="#8A613C" strokeWidth="2" />
            <circle cx="65" cy="65" r="8" fill="#E5C3A6" />
            
            {/* Right Ear */}
            <circle cx="135" cy="65" r="15" fill="#A87B51" stroke="#8A613C" strokeWidth="2" />
            <circle cx="135" cy="65" r="8" fill="#E5C3A6" />

            {/* Head */}
            <ellipse cx="100" cy="90" rx="42" ry="36" fill="#A87B51" stroke="#8A613C" strokeWidth="2" />
            
            {/* Muzzle */}
            <ellipse cx="100" cy="102" rx="22" ry="16" fill="#E5C3A6" />
            
            {/* Nose */}
            <ellipse cx="100" cy="96" rx="7" ry="5" fill="#332211" />
            <path d="M 100 100 L 100 106" stroke="#332211" strokeWidth="2" strokeLinecap="round" />
            
            {/* Mouth */}
            {state === 'happy' ? (
              <path d="M 90 106 Q 100 114 110 106" fill="transparent" stroke="#332211" strokeWidth="2" strokeLinecap="round" />
            ) : state === 'surprise' ? (
              <circle cx="100" cy="110" r="4" fill="#332211" />
            ) : (
              <path d="M 93 107 Q 100 111 107 107" fill="transparent" stroke="#332211" strokeWidth="2" strokeLinecap="round" />
            )}

            {/* Eyes */}
            <motion.g variants={eyeVariants} style={{ originX: '100px', originY: '80px' }}>
              <circle cx="82" cy="80" r="4.5" fill="#332211" />
              <circle cx="118" cy="80" r="4.5" fill="#332211" />
            </motion.g>
            
            {/* Blushes */}
            {(state === 'shy' || state === 'love') && (
              <>
                <ellipse cx="72" cy="95" rx="7" ry="4" fill="#FF9EAA" opacity="0.8" />
                <ellipse cx="128" cy="95" rx="7" ry="4" fill="#FF9EAA" opacity="0.8" />
              </>
            )}
          </motion.g>

          {/* Arms moved to the front to cover the face in shy state */}
          {/* Left Arm (In front of body and head) */}
          <motion.g variants={armLeftVariants} style={{ originX: '70px', originY: '120px' }}>
             <path d="M 60 110 C 40 110, 30 140, 45 160 C 55 170, 75 145, 75 125" fill="#A87B51" stroke="#8A613C" strokeWidth="2" strokeLinejoin="round" />
          </motion.g>

          {/* Right Arm (In front of body and head) */}
          <motion.g variants={armRightVariants} style={{ originX: '130px', originY: '120px' }}>
            <path d="M 140 110 C 160 110, 170 140, 155 160 C 145 170, 125 145, 125 125" fill="#A87B51" stroke="#8A613C" strokeWidth="2" strokeLinejoin="round" />
          </motion.g>
        </motion.g>
      </motion.svg>
    </div>
  );
};
