/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AnimatePresence } from 'motion/react';
import { useSecretsStore } from './store/useSecretsStore';
import { WelcomeScreen } from './screens/WelcomeScreen';
import { PermissionScreen } from './screens/PermissionScreen';
import { ExperienceScreen } from './screens/ExperienceScreen';
import { FinaleScreen } from './screens/FinaleScreen';
import { useEffect } from 'react';

export default function App() {
  const currentScreen = useSecretsStore(state => state.currentScreen);
  const isFinaleTriggered = useSecretsStore(state => state.isFinaleTriggered);
  const setScreen = useSecretsStore(state => state.setScreen);

  useEffect(() => {
    if (isFinaleTriggered && currentScreen !== 'finale') {
      setScreen('finale');
    }
  }, [isFinaleTriggered, currentScreen, setScreen]);

  return (
    <div className="w-full min-h-[100dvh] bg-rose-50 font-tajawal selection:bg-rose-200">
      <AnimatePresence mode="wait">
        {currentScreen === 'welcome' && <WelcomeScreen key="welcome" />}
        {currentScreen === 'permission' && <PermissionScreen key="permission" />}
        {currentScreen === 'experience' && <ExperienceScreen key="experience" />}
        {currentScreen === 'finale' && <FinaleScreen key="finale" />}
      </AnimatePresence>
    </div>
  );
}
